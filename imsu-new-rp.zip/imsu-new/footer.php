<?php
require_once ('footer.content.php');
require_once ('JS.plugin.php');
?>
    </body>
</html>
