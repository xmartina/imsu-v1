<!-- ==============================================
    ** About **
    =================================================== -->
<section class="about">
    <div class="container">
        <ul class="row our-links">
            <li class="col-sm-4 apply-online clearfix equal-hight">
                <div class="icon"><img src="images/hat.png" class="img-responsive" alt=""></div>
                <div class="detail">
                    <h3><span>Undergraduate</span>Studies</h3>
                    <p> ...an innovation ecosystem dedicated to producing problem solvers. </p>
                    <a href="" class="more"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                </div>
            </li>
            <li class="col-sm-4 prospects clearfix equal-hight">
                <div class="icon"><img src="images/postg.png" class="img-responsive" alt=""></div>
                <div class="detail">
                    <h3><span>Postgraduate</span>Studies</h3>
                    <p> ...an innovation ecosystem dedicated to producing problem solvers. </p>
                    <a href="#" class="more"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                </div>
            </li>
            <li class="col-sm-4 certification clearfix equal-hight">
                <div class="icon"><img src="images/certification-ico.png" class="img-responsive" alt=""></div>
                <div class="detail">
                    <h3><span>Continuing</span> Education</h3>
                    <p> ...an innovation ecosystem dedicated to producing problem solvers. </p>
                    <a href="#" class="more"><i class="fa fa-angle-right" aria-hidden="true"></i></a>
                </div>
            </li>
        </ul>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-sm-7 col-sm-push-5 left-block"> <span class="sm-head">Welcome to</span>
                <h2>Imo State University</h2>
                <p style="color: black; text-align: justify;">The transition to an environment of learning becomes easy with the availability of multiple sources of learning such as text books, power-point presentations, and story boards on various subjects. The transition to an environment of learning becomes easy with the availability of multiple sources of learning such as text books, power-point presentations, and story boards on various subjects.
                    The transition to an environment of learning becomes easy with the availability of multiple sources of learning such as text books, power-point presentations, and story boards on various subjects.
                </p>

                <a href="" class="btn animated fadeInLeft">Read More</a>
            </div>
            <div class="col-sm-5 col-sm-pull-6">
                <div class="video-block">
                    <img src="images/vc.jpg" style="width: 350px;">
                    <!-- <div id="thumbnail_container"> <img src="images/about-video.jpg" id="thumbnail" class="img-responsive" alt=""> </div>
                    <a href="https://www.youtube.com/watch?v=i11RXCJVEnw" class="start-video video"><img src="images/play-btn.png" alt=""></a> -->
                </div>
            </div>
        </div>
    </div>
</section>