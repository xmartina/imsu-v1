<?php
require_once ('header.php');
require_once ('home.banner.outer.php');
require_once ('home.about.php');
require_once ('home.discover.more.php');
require_once ('home.how.study.php');
require_once('home.faculties.directorates.php');
require_once ('home.upcoming.events.php');
require_once ('home.campus.tour.php');
require_once ('home.testimonial.php');
require_once ('footer.php');
?>