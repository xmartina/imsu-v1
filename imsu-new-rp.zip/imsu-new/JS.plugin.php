<!-- Optional JavaScript -->
<script src="js/jquery.min.js"></script>
<script src="assets/bootstrap/js/bootstrap.min.js"></script>
<script src="assets/select2/js/select2.min.js"></script>
<script src="assets/matchHeight/js/matchHeight-min.js"></script>
<script src="assets/bxslider/js/bxslider.min.js"></script>
<script src="assets/waypoints/js/waypoints.min.js"></script>
<script src="assets/counterup/js/counterup.min.js"></script>
<script src="assets/magnific-popup/js/magnific-popup.min.js"></script>
<script src="assets/owl-carousel/js/owl.carousel.min.js"></script>
<script src="js/modernizr.custom.js"></script>
<script src="js/custom.js"></script>