<!-- ==============================================
** Testimonials **
=================================================== -->
<section class="testimonial padding-lg">
    <div class="container">
        <div class="wrapper">
            <h2>IMSU Testimonies</h2>
            <ul class="testimonial-slide">
                <li>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley...</p>
                    <span>Eze, <span>Abia</span></span>
                </li>
                <li>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley...</p>
                    <span>Ikenna, <span>London</span></span>
                </li>
                <li>
                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley...</p>
                    <span>Chinonso, <span>Imo</span></span>
                </li>
            </ul>
            <div id="bx-pager">
                <a data-slide-index="0" href="#"><img src="images/ins33.jpg" class="img-circle" alt="" /></a>
                <a data-slide-index="1" href="#"><img src="images/ins44.jpg" class="img-circle" alt="" /></a>
                <a data-slide-index="2" href="#"><img src="images/test.jpg" class="img-circle" alt="" /></a>
            </div>
        </div>
    </div>
</section>
